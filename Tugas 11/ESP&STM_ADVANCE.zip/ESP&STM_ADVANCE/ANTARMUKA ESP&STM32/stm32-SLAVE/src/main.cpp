#include <Arduino.h>
#include <STM32FreeRTOS.h>
#include <Wire.h>
#include <DHT.h>

#define SLAVE_ADDR 0x08

#define DHTPIN PA0
#define DHTTYPE DHT22
#define POT_PIN PA3       
#define MQ2_PIN PA4       
#define DAC_PIN PA5       
#define LED_ADC_PIN PB0   

DHT dht(DHTPIN, DHTTYPE);

struct DataSensor {
  int16_t temperature; 
  int16_t humidity;    
  int16_t distance;    
  int16_t pot;         
  int16_t mq2;         
  int16_t dacValue;    
};

volatile DataSensor dataKirim;

void TaskBacaDigital(void *pvParameters);
void TaskBacaAnalogDanDAC(void *pvParameters);
void requestEvent();

void setup() {
  dht.begin();
  
  pinMode(POT_PIN, INPUT_ANALOG);
  pinMode(MQ2_PIN, INPUT_ANALOG);
  pinMode(LED_ADC_PIN, OUTPUT);
  pinMode(DAC_PIN, OUTPUT);

  analogReadResolution(12);
  analogWriteResolution(8); 

  // Inisialisasi I2C Slave
  Wire.begin(SLAVE_ADDR);
  Wire.onRequest(requestEvent);

  xTaskCreate(TaskBacaDigital, "DigSens", 128, NULL, 1, NULL);
  xTaskCreate(TaskBacaAnalogDanDAC, "AnaDAC", 128, NULL, 2, NULL);

  vTaskStartScheduler();
}

void loop() {
  // Dikelola FreeRTOS
}

void TaskBacaDigital(void *pvParameters) {
  for(;;) {
    float t = dht.readTemperature();
    float h = dht.readHumidity();
    
    // Gunakan portENTER_CRITICAL untuk mencegah korupsi data saat I2C membaca struct
    portENTER_CRITICAL();
    if (!isnan(t) && !isnan(h)) {
      dataKirim.temperature = (int16_t)(t * 10); 
      dataKirim.humidity = (int16_t)(h * 10);    
    }
    dataKirim.distance = 0;
    portEXIT_CRITICAL();

    vTaskDelay(pdMS_TO_TICKS(1000)); 
  }
}

void TaskBacaAnalogDanDAC(void *pvParameters) {
  for(;;) {
    int16_t nilaiPot = analogRead(POT_PIN);
    int16_t nilaiMQ2 = analogRead(MQ2_PIN);
    
    if(nilaiPot < 0) nilaiPot = 0;
    if(nilaiPot > 4095) nilaiPot = 4095;

    portENTER_CRITICAL();
    dataKirim.pot = nilaiPot;
    dataKirim.mq2 = nilaiMQ2;
    portEXIT_CRITICAL();

    int ledBrightness = map(nilaiPot, 0, 4095, 0, 255);
    analogWrite(LED_ADC_PIN, ledBrightness);

    int dacOutValue = map(nilaiPot, 0, 4095, 0, 255); 
    analogWrite(DAC_PIN, dacOutValue);
    
    portENTER_CRITICAL();
    dataKirim.dacValue = nilaiPot; 
    portEXIT_CRITICAL();

    vTaskDelay(pdMS_TO_TICKS(50)); 
  }
}

void requestEvent() {
  // Mengirim struct utuh 12-byte
  Wire.write((uint8_t*)&dataKirim, sizeof(dataKirim));
}