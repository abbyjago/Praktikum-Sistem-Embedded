#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <SPI.h>
#include <SD.h>

#define SLAVE_ADDR 0x08

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

#define SD_CS_PIN 5
#define BUTTON_PIN 4
#define ESP_LED_PIN 2     

struct DataSensor {
  int16_t temperature;
  int16_t humidity;
  int16_t distance;    
  int16_t pot;
  int16_t mq2;
  int16_t dacValue;
};

DataSensor dataTerima;
SemaphoreHandle_t dataMutex;

volatile uint8_t sdCardStatus = 0; 

void TaskAmbilDataI2C(void *pvParameters);
void TaskUpdateOLED(void *pvParameters);
void TaskDatalogger(void *pvParameters);

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(ESP_LED_PIN, OUTPUT);
  
  pinMode(SD_CS_PIN, OUTPUT);
  digitalWrite(SD_CS_PIN, HIGH); 
  delay(500);                    

  dataMutex = xSemaphoreCreateMutex();

  // ==========================================
  // I2C diturunkan ke 50kHz agar STM32 Slave sempat merespons
  // ==========================================
  Wire.begin(21, 22, 50000); 

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    Serial.println("OLED Master Gagal!");
    for(;;);
  }
  display.clearDisplay();

  digitalWrite(SD_CS_PIN, LOW); 
  if(!SD.begin(SD_CS_PIN, SPI, 1000000)) {
    Serial.println("Gagal Inisialisasi SD Card!");
    digitalWrite(SD_CS_PIN, HIGH); 
    sdCardStatus = 2; 
  } else {
    File root = SD.open("/datalog.csv", FILE_WRITE);
    if(root) {
      root.println("Timestamp_ms,Temp_C,Hum_percent,Pot_ADC,MQ2_ADC,DAC_Val");
      root.close();
      sdCardStatus = 1; 
    } else {
      sdCardStatus = 2; 
    }
    digitalWrite(SD_CS_PIN, HIGH); 
  }

  xTaskCreatePinnedToCore(TaskAmbilDataI2C, "GetI2C", 3000, NULL, 3, NULL, 1);
  xTaskCreatePinnedToCore(TaskUpdateOLED, "OLED", 4000, NULL, 2, NULL, 1);
  xTaskCreatePinnedToCore(TaskDatalogger, "LogSD", 4000, NULL, 2, NULL, 0); 
}

void loop() {
  // Dikelola FreeRTOS
}

void TaskAmbilDataI2C(void *pvParameters) {
  for(;;) {
    byte dataSize = sizeof(dataTerima);
    // Permintaan I2C dengan jeda blocking minimal
    byte bytesReceived = Wire.requestFrom((uint8_t)SLAVE_ADDR, (uint8_t)dataSize);
    
    if (bytesReceived >= dataSize) {
      if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
        Wire.readBytes((uint8_t*)&dataTerima, dataSize);
        xSemaphoreGive(dataMutex); 
      }
      digitalWrite(ESP_LED_PIN, HIGH); 
    } else {
      digitalWrite(ESP_LED_PIN, LOW);  
    }
    vTaskDelay(pdMS_TO_TICKS(150)); // Diberi jeda lebih longgar agar bus I2C stabil
  }
}

void TaskUpdateOLED(void *pvParameters) {
  for(;;) {
    DataSensor lokalData;
    
    if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
      lokalData = dataTerima;
      xSemaphoreGive(dataMutex);
    }

    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    
    float tempFloat = lokalData.temperature / 10.0;
    float humFloat = lokalData.humidity / 10.0;
    float dacVolt = (lokalData.dacValue / 4095.0) * 3.3; 

    display.setCursor(0, 0);
    display.printf("T: %.1fC | H: %.1f%%", tempFloat, humFloat);
    
    display.setCursor(0, 16);
    display.printf("Pot: %d | MQ2: %d", lokalData.pot, lokalData.mq2);
    
    display.setCursor(0, 32);
    display.printf("DAC Out: %.2f V", dacVolt); 
    
    display.setCursor(0, 48);
    display.print("SD Card: ");
    if (sdCardStatus == 1) {
      display.print("READY (FAT32)");
    } else {
      display.print("ERR / NOT FOUND");
    }
    
    display.display();
    vTaskDelay(pdMS_TO_TICKS(200)); 
  }
}

void TaskDatalogger(void *pvParameters) {
  bool lastButtonState = HIGH;
  for(;;) {
    bool currentButtonState = digitalRead(BUTTON_PIN);
    
    if (lastButtonState == HIGH && currentButtonState == LOW) {
      Serial.println("Tombol Ditekan! Menyimpan data...");
      
      DataSensor lokalData;
      if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
        lokalData = dataTerima;
        xSemaphoreGive(dataMutex);
      }

      digitalWrite(SD_CS_PIN, LOW);
      File logFile = SD.open("/datalog.csv", FILE_APPEND);
      
      if (logFile) {
        logFile.printf("%lu,%.1f,%.1f,%d,%d,%d\n", 
                       millis(), 
                       lokalData.temperature/10.0, 
                       lokalData.humidity/10.0, 
                       lokalData.pot, 
                       lokalData.mq2,
                       lokalData.dacValue);
        logFile.close();
        Serial.println("Data sukses masuk ke datalog.csv!");
        sdCardStatus = 1; 
      } else {
        Serial.println("Gagal menulis ke SD Card!");
        sdCardStatus = 2; 
      }
      digitalWrite(SD_CS_PIN, HIGH);
      
      vTaskDelay(pdMS_TO_TICKS(200)); 
    }
    lastButtonState = currentButtonState;
    vTaskDelay(pdMS_TO_TICKS(50));
  }
}