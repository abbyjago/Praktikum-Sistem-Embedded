#include <Arduino.h>

#define POT_PIN PA0   // Potensiometer ke ADC
#define LED_PIN PA8   // LED eksternal ke pin PWM (seri resistor)

const uint16_t ADC_MAX = 4095;
const uint16_t PWM_MAX = 4095;
const float VREF = 3.3f;

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("Kontrol Kecerahan LED dengan Potensiometer (ADC -> PWM)");
    Serial.println("Putar potensiometer untuk mengubah duty cycle PWM.");
    Serial.println("Monitor via FTDI @ 115200 baud");
    Serial.println("ADC | Vpot(V) | PWM | Duty(%) | Vled_avg(V)");

    analogReadResolution(12);   // ADC: 0..4095
    analogWriteResolution(12);  // PWM: 0..4095

    pinMode(POT_PIN, INPUT_ANALOG);
    pinMode(LED_PIN, OUTPUT);
}

void loop() {
    uint16_t adcValue = analogRead(POT_PIN);  // 0..4095
    uint16_t pwmValue = map(adcValue, 0, ADC_MAX, 0, PWM_MAX);
    analogWrite(LED_PIN, pwmValue);

    float dutyPercent = (pwmValue * 100.0f) / PWM_MAX;
    float potVoltage = (adcValue * VREF) / ADC_MAX;
    float ledAverageVoltage = (pwmValue * VREF) / PWM_MAX;

    Serial.print("ADC: ");
    Serial.print(adcValue);
    Serial.print(" | Vpot: ");
    Serial.print(potVoltage, 3);
    Serial.print(" V");
    Serial.print(" | PWM: ");
    Serial.print(pwmValue);
    Serial.print(" | Duty: ");
    Serial.print(dutyPercent, 1);
    Serial.print(" %");
    Serial.print(" | Vled_avg: ");
    Serial.print(ledAverageVoltage, 3);
    Serial.println(" V");

    delay(30);
}
