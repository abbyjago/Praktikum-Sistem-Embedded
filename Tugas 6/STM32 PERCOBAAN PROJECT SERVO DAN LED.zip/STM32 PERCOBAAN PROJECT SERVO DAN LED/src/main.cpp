#include <Arduino.h>

#define POT_PIN   PA0   // Potensiometer ke ADC
#define LED_PIN   PA1   // LED dengan PWM brightness
#define SERVO_PIN PA8   // Pin PWM ke sinyal servo SG90

HardwareTimer *servoTimer = nullptr;

// Konstanta tuning agar gerak servo lebih halus dan tidak jitter.
const int ADC_MIN = 0;
const int ADC_MAX = 4095;
const int SERVO_MIN_ANGLE = 0;
const int SERVO_MAX_ANGLE = 180;
const int SERVO_DEADBAND = 2;      // Update servo hanya jika perubahan >= 2 derajat
const float FILTER_ALPHA = 0.15f;  // Semakin kecil -> semakin halus tapi respon lebih lambat
const uint32_t SERVO_PERIOD_US = 20000;   // 50 Hz
const uint32_t SERVO_MIN_US = 500;        // pulse minimum SG90
const uint32_t SERVO_MAX_US = 2400;       // pulse maksimum SG90

float filteredAdc = 0.0f;
int lastServoAngle = -999;

static uint32_t angleToPulseUs(int angle) {
    return map(angle, SERVO_MIN_ANGLE, SERVO_MAX_ANGLE, SERVO_MIN_US, SERVO_MAX_US);
}

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("Kontrol Servo SG90 dan LED dengan Potensiometer");

    analogReadResolution(12);   // ADC 0..4095
    analogWriteResolution(12);  // PWM LED 0..4095

    pinMode(POT_PIN, INPUT_ANALOG);
    pinMode(LED_PIN, OUTPUT);
    pinMode(SERVO_PIN, OUTPUT);

    // Konfigurasi PWM servo murni via timer: PA8 = TIM1_CH1.
    servoTimer = new HardwareTimer(TIM1);
    servoTimer->setOverflow(SERVO_PERIOD_US, MICROSEC_FORMAT);
    servoTimer->setMode(1, TIMER_OUTPUT_COMPARE_PWM1, SERVO_PIN);
    servoTimer->setCaptureCompare(1, angleToPulseUs(90), MICROSEC_COMPARE_FORMAT);
    servoTimer->resume();

    // Inisialisasi filter dari pembacaan awal agar startup lebih stabil.
    filteredAdc = analogRead(POT_PIN);
}

void loop() {
    int adcValue = analogRead(POT_PIN);                  // 0..4095

    // Exponential moving average untuk mengurangi noise ADC.
    filteredAdc = (FILTER_ALPHA * adcValue) + ((1.0f - FILTER_ALPHA) * filteredAdc);
    int stableAdc = (int)(filteredAdc + 0.5f);

    int ledValue = map(stableAdc, ADC_MIN, ADC_MAX, 0, 4095);  // brightness LED mengikuti pot
    analogWrite(LED_PIN, ledValue);                  // LED redup-terang sesuai nilai pot

    int angle = map(stableAdc, ADC_MIN, ADC_MAX, SERVO_MIN_ANGLE, SERVO_MAX_ANGLE);
    angle = constrain(angle, SERVO_MIN_ANGLE, SERVO_MAX_ANGLE);

    if (abs(angle - lastServoAngle) >= SERVO_DEADBAND) {
        uint32_t pulseUs = angleToPulseUs(angle);
        servoTimer->setCaptureCompare(1, pulseUs, MICROSEC_COMPARE_FORMAT);
        lastServoAngle = angle;
    }

    Serial.print("ADC: ");
    Serial.print(adcValue);
    Serial.print(" | ADC filter: ");
    Serial.print(stableAdc);
    Serial.print(" | LED PWM: ");
    Serial.print(ledValue);
    Serial.print(" | Sudut Servo: ");
    Serial.println(lastServoAngle);

    delay(20);  // update rate ~50 Hz
}
