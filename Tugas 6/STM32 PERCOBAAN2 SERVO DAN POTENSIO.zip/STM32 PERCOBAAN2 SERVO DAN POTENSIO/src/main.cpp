#include <Arduino.h>
#include <Servo.h>

#define POT_PIN   PA0   // Potensiometer ke ADC
#define DAC_PIN   PA4   // DAC1 STM32 (monitor nilai analog hasil mapping)
#define SERVO_PIN PA8   // Pin PWM ke sinyal servo SG90

Servo myServo;

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("Kontrol Servo SG90 dengan Potensiometer (ADC -> DAC -> PWM)");

    analogReadResolution(12);   // ADC 0..4095
    analogWriteResolution(12);  // DAC 0..4095

    pinMode(POT_PIN, INPUT_ANALOG);
    pinMode(DAC_PIN, OUTPUT);

    myServo.attach(SERVO_PIN);
}

void loop() {
    int adcValue = analogRead(POT_PIN);              // 0..4095
    int dacValue = adcValue;                         // implementasi nilai DAC dari hasil ADC
    analogWrite(DAC_PIN, dacValue);                  // keluar sebagai tegangan analog di PA4

    int angle = map(dacValue, 0, 4095, 0, 180);
    angle = constrain(angle, 0, 180);
    myServo.write(angle);

    Serial.print("ADC: ");
    Serial.print(adcValue);
    Serial.print(" | DAC: ");
    Serial.print(dacValue);
    Serial.print(" | Sudut Servo: ");
    Serial.println(angle);

    delay(20);  // update rate ~50 Hz
}
