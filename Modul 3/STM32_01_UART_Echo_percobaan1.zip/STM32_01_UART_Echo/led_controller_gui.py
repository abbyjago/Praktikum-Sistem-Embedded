"""
STM32 LED Controller - Hello Kitty Theme
Control 2 LEDs via UART/FTDI Communication
With Cute Animations! 🎀✨
"""

import tkinter as tk
from tkinter import ttk, messagebox
import serial
import serial.tools.list_ports
import threading
import time
import math

class HelloKittyLEDController:
    def __init__(self, root):
        self.root = root
        self.root.title("🎀 Hello Kitty LED Controller 🎀")
        self.root.geometry("750x700")
        self.root.resizable(False, False)
        
        # Hello Kitty color scheme - Pink and cute!
        self.bg_color = "#FFB6C1"  # Light pink
        self.button_color = "#FF69B4"  # Hot pink
        self.led_off_color = "#FFE4E1"  # Misty rose
        self.led_on_color = "#FF1493"  # Deep pink
        self.text_color = "#FF1493"
        
        self.root.configure(bg=self.bg_color)
        
        # Serial connection
        self.serial_port = None
        self.is_connected = False
        
        # LED states
        self.led1_state = False
        self.led2_state = False
        
        # Hide window initially for splash
        self.root.withdraw()
        
        # Show splash screen with animation
        self.show_splash_screen()
        
    def show_splash_screen(self):
        """Show animated splash screen"""
        splash = tk.Toplevel()
        splash.title("Loading...")
        splash.geometry("500x400")
        splash.configure(bg=self.bg_color)
        splash.overrideredirect(True)  # Remove window border
        
        # Center splash screen
        splash.update_idletasks()
        x = (splash.winfo_screenwidth() // 2) - (500 // 2)
        y = (splash.winfo_screenheight() // 2) - (400 // 2)
        splash.geometry(f"500x400+{x}+{y}")
        
        # Title with animation
        title = tk.Label(
            splash,
            text="🎀 ✨ Hello Kitty ✨ 🎀",
            font=("Comic Sans MS", 28, "bold"),
            bg=self.bg_color,
            fg=self.text_color
        )
        title.pack(pady=40)
        
        subtitle = tk.Label(
            splash,
            text="LED Controller",
            font=("Comic Sans MS", 20),
            bg=self.bg_color,
            fg=self.text_color
        )
        subtitle.pack(pady=10)
        
        # Cute ASCII art
        art = tk.Label(
            splash,
            text="   /\\_/\\  \n  ( o.o ) \n   > ^ <",
            font=("Courier", 16, "bold"),
            bg=self.bg_color,
            fg=self.text_color
        )
        art.pack(pady=20)
        
        loading_text = tk.Label(
            splash,
            text="Loading cuteness...",
            font=("Comic Sans MS", 12),
            bg=self.bg_color,
            fg=self.text_color
        )
        loading_text.pack(pady=20)
        
        # Progress bar
        progress = ttk.Progressbar(
            splash,
            length=300,
            mode='indeterminate'
        )
        progress.pack(pady=20)
        progress.start(10)
        
        # Fade in animation
        self.fade_in_splash(splash, title, 0)
        
        # Close splash and show main window after delay
        splash.after(3000, lambda: self.close_splash(splash, progress))
        
    def fade_in_splash(self, splash, title, alpha):
        """Fade in animation for splash screen"""
        if alpha < 1.0:
            alpha += 0.05
            # Animate by changing size
            size = int(20 + alpha * 8)
            title.config(font=("Comic Sans MS", size, "bold"))
            splash.after(50, lambda: self.fade_in_splash(splash, title, alpha))
    
    def close_splash(self, splash, progress):
        """Close splash and show main window with bounce animation"""
        progress.stop()
        splash.destroy()
        self.root.deiconify()
        
        # Create main window content
        self.create_widgets()
        self.update_connection_status()
        
        # Bounce animation for main window
        self.bounce_window(0, 20)
        
    def bounce_window(self, step, max_steps):
        """Bounce animation when window appears"""
        if step < max_steps:
            # Calculate bounce offset
            progress = step / max_steps
            offset = int(30 * math.sin(progress * math.pi))
            
            # Update window position
            x = (self.root.winfo_screenwidth() // 2) - (750 // 2)
            y = (self.root.winfo_screenheight() // 2) - (700 // 2) - offset
            self.root.geometry(f"750x700+{x}+{y}")
            
            self.root.after(30, lambda: self.bounce_window(step + 1, max_steps))
        else:
            # Final position
            x = (self.root.winfo_screenwidth() // 2) - (750 // 2)
            y = (self.root.winfo_screenheight() // 2) - (700 // 2)
            self.root.geometry(f"750x700+{x}+{y}")
        
    def create_widgets(self):
        # Title with Hello Kitty decorations
        title_frame = tk.Frame(self.root, bg=self.bg_color)
        title_frame.pack(pady=20)
        
        title = tk.Label(
            title_frame,
            text="🎀 ✨ Hello Kitty LED Controller ✨ 🎀",
            font=("Comic Sans MS", 18, "bold"),
            bg=self.bg_color,
            fg=self.text_color
        )
        title.pack()
        
        subtitle = tk.Label(
            title_frame,
            text="Control your STM32 LEDs with cuteness! 💖",
            font=("Comic Sans MS", 10),
            bg=self.bg_color,
            fg=self.text_color
        )
        subtitle.pack()
        
        # Connection Frame
        conn_frame = tk.LabelFrame(
            self.root,
            text="🔌 Connection",
            font=("Comic Sans MS", 12, "bold"),
            bg=self.bg_color,
            fg=self.text_color,
            bd=3
        )
        conn_frame.pack(pady=10, padx=20, fill="x")
        
        # COM Port selection
        port_frame = tk.Frame(conn_frame, bg=self.bg_color)
        port_frame.pack(pady=10, padx=10)
        
        tk.Label(
            port_frame,
            text="COM Port:",
            font=("Comic Sans MS", 10),
            bg=self.bg_color,
            fg=self.text_color
        ).grid(row=0, column=0, padx=5)
        
        self.port_combo = ttk.Combobox(port_frame, width=15, state="readonly")
        self.port_combo.grid(row=0, column=1, padx=5)
        self.refresh_ports()
        
        refresh_btn = tk.Button(
            port_frame,
            text="🔄",
            command=self.refresh_ports,
            bg=self.button_color,
            fg="white",
            font=("Comic Sans MS", 10, "bold"),
            relief="raised",
            bd=3
        )
        refresh_btn.grid(row=0, column=2, padx=5)
        
        self.connect_btn = tk.Button(
            port_frame,
            text="Connect 💕",
            command=self.toggle_connection,
            bg=self.button_color,
            fg="white",
            font=("Comic Sans MS", 10, "bold"),
            width=15,
            relief="raised",
            bd=3
        )
        self.connect_btn.grid(row=0, column=3, padx=5)
        
        self.status_label = tk.Label(
            conn_frame,
            text="● Disconnected",
            font=("Comic Sans MS", 9),
            bg=self.bg_color,
            fg="red"
        )
        self.status_label.pack(pady=5)
        
        # LED Control Frame
        led_frame = tk.LabelFrame(
            self.root,
            text="💡 LED Controls",
            font=("Comic Sans MS", 12, "bold"),
            bg=self.bg_color,
            fg=self.text_color,
            bd=3
        )
        led_frame.pack(pady=20, padx=20, fill="both", expand=True)
        
        # Main container untuk 2 LED side by side
        main_container = tk.Frame(led_frame, bg=self.bg_color)
        main_container.pack(pady=10, padx=20, expand=True)
        
        # ============== LED 1 Control ==============
        led1_container = tk.Frame(main_container, bg=self.bg_color, relief="ridge", bd=5, padx=15, pady=15)
        led1_container.grid(row=0, column=0, padx=15, pady=10)
        
        tk.Label(
            led1_container,
            text="✨ LED 1 ✨",
            font=("Comic Sans MS", 16, "bold"),
            bg=self.bg_color,
            fg=self.text_color
        ).pack(pady=5)
        
        # Indikator LED 1
        self.led1_indicator = tk.Canvas(
            led1_container,
            width=100,
            height=100,
            bg=self.bg_color,
            highlightthickness=0
        )
        self.led1_indicator.pack(pady=10)
        self.led1_circle = self.led1_indicator.create_oval(
            15, 15, 85, 85,
            fill=self.led_off_color,
            outline=self.text_color,
            width=4
        )
        
        # Status label LED 1
        self.led1_status = tk.Label(
            led1_container,
            text="● OFF",
            font=("Comic Sans MS", 14, "bold"),
            bg=self.bg_color,
            fg="gray"
        )
        self.led1_status.pack(pady=5)
        
        # Button Toggle LED 1
        self.led1_btn = tk.Button(
            led1_container,
            text="🎀 TOGGLE 🎀",
            command=lambda: self.toggle_led(1),
            bg=self.button_color,
            fg="white",
            font=("Comic Sans MS", 12, "bold"),
            width=15,
            height=2,
            relief="raised",
            bd=5,
            cursor="hand2"
        )
        self.led1_btn.pack(pady=10)
        
        # ============== LED 2 Control ==============
        led2_container = tk.Frame(main_container, bg=self.bg_color, relief="ridge", bd=5, padx=15, pady=15)
        led2_container.grid(row=0, column=1, padx=15, pady=10)
        
        tk.Label(
            led2_container,
            text="⭐ LED 2 ⭐",
            font=("Comic Sans MS", 16, "bold"),
            bg=self.bg_color,
            fg=self.text_color
        ).pack(pady=5)
        
        # Indikator LED 2
        self.led2_indicator = tk.Canvas(
            led2_container,
            width=100,
            height=100,
            bg=self.bg_color,
            highlightthickness=0
        )
        self.led2_indicator.pack(pady=10)
        self.led2_circle = self.led2_indicator.create_oval(
            15, 15, 85, 85,
            fill=self.led_off_color,
            outline=self.text_color,
            width=4
        )
        
        # Status label LED 2
        self.led2_status = tk.Label(
            led2_container,
            text="● OFF",
            font=("Comic Sans MS", 14, "bold"),
            bg=self.bg_color,
            fg="gray"
        )
        self.led2_status.pack(pady=5)
        
        # Button Toggle LED 2
        self.led2_btn = tk.Button(
            led2_container,
            text="🌸 TOGGLE 🌸",
            command=lambda: self.toggle_led(2),
            bg=self.button_color,
            fg="white",
            font=("Comic Sans MS", 12, "bold"),
            width=15,
            height=2,
            relief="raised",
            bd=5,
            cursor="hand2"
        )
        self.led2_btn.pack(pady=10)
        
        # Footer
        footer = tk.Label(
            self.root,
            text="Made with 💖 by Hello Kitty Fan",
            font=("Comic Sans MS", 8),
            bg=self.bg_color,
            fg=self.text_color
        )
        footer.pack(side="bottom", pady=10)
        
    def refresh_ports(self):
        """Refresh available COM ports"""
        ports = serial.tools.list_ports.comports()
        port_list = [port.device for port in ports]
        self.port_combo['values'] = port_list
        if port_list:
            self.port_combo.current(0)
    
    def toggle_connection(self):
        """Connect or disconnect from serial port"""
        if not self.is_connected:
            # Connect
            port = self.port_combo.get()
            if not port:
                messagebox.showerror("Error", "Please select a COM port!")
                return
            
            try:
                self.serial_port = serial.Serial(port, 115200, timeout=1)
                time.sleep(2)  # Wait for Arduino reset
                self.is_connected = True
                self.connect_btn.config(text="Disconnect 💔")
                self.status_label.config(text="● Connected", fg="green")
                messagebox.showinfo("Success", f"Connected to {port}! 🎉")
                
                # Celebrate with animation
                self.celebrate_connection()
                
                # Start reading thread
                self.read_thread = threading.Thread(target=self.read_serial, daemon=True)
                self.read_thread.start()
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to connect:\n{str(e)}")
        else:
            # Disconnect
            if self.serial_port:
                self.serial_port.close()
            self.is_connected = False
            self.connect_btn.config(text="Connect 💕")
            self.status_label.config(text="● Disconnected", fg="red")
    
    def toggle_led(self, led_num):
        """Toggle LED on/off with button animation"""
        if not self.is_connected:
            messagebox.showwarning("Warning", "Please connect to STM32 first! 🔌")
            return
        
        # Button press animation
        btn = self.led1_btn if led_num == 1 else self.led2_btn
        self.animate_button_press(btn, 0)
        
        try:
            # Send command
            command = str(led_num)
            self.serial_port.write(command.encode())
            
            # Update local state (will be confirmed by serial response)
            if led_num == 1:
                self.led1_state = not self.led1_state
                self.update_led_indicator(1, self.led1_state)
                if self.led1_state:
                    self.start_led_pulse_animation(1)
            else:
                self.led2_state = not self.led2_state
                self.update_led_indicator(2, self.led2_state)
                if self.led2_state:
                    self.start_led_pulse_animation(2)
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to send command:\n{str(e)}")
    
    def animate_button_press(self, button, step):
        """Animate button press effect"""
        if step < 5:
            # Press down
            button.config(relief="sunken" if step < 2 else "raised")
            self.root.after(50, lambda: self.animate_button_press(button, step + 1))
    
    def start_led_pulse_animation(self, led_num):
        """Start pulsing animation for LED when it turns on"""
        self.pulse_led_indicator(led_num, 0, 10)
    
    def pulse_led_indicator(self, led_num, step, max_steps):
        """Pulse animation for LED indicator"""
        if step < max_steps:
            # Calculate pulse scale
            progress = step / max_steps
            scale = 1.0 + 0.2 * math.sin(progress * math.pi * 4)
            
            # Update LED size
            canvas = self.led1_indicator if led_num == 1 else self.led2_indicator
            circle = self.led1_circle if led_num == 1 else self.led2_circle
            
            center = 50
            radius = int(35 * scale)
            canvas.coords(circle, center - radius, center - radius, 
                         center + radius, center + radius)
            
            self.root.after(50, lambda: self.pulse_led_indicator(led_num, step + 1, max_steps))
        else:
            # Reset to normal size
            canvas = self.led1_indicator if led_num == 1 else self.led2_indicator
            circle = self.led1_circle if led_num == 1 else self.led2_circle
            canvas.coords(circle, 15, 15, 85, 85)
    
    def update_led_indicator(self, led_num, state):
        """Update LED indicator on GUI"""
        color = self.led_on_color if state else self.led_off_color
        status_text = "● ON" if state else "● OFF"
        status_color = "#FF1493" if state else "gray"
        
        if led_num == 1:
            self.led1_indicator.itemconfig(self.led1_circle, fill=color)
            self.led1_status.config(text=status_text, fg=status_color)
        else:
            self.led2_indicator.itemconfig(self.led2_circle, fill=color)
            self.led2_status.config(text=status_text, fg=status_color)
    
    def read_serial(self):
        """Read serial data in background thread"""
        while self.is_connected:
            try:
                if self.serial_port and self.serial_port.in_waiting:
                    line = self.serial_port.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        print(f"STM32: {line}")  # Debug output
                        
                        # Parse LED status responses
                        if "LED1:ON" in line:
                            self.led1_state = True
                            # Schedule update in main thread (thread-safe!)
                            self.root.after(0, lambda: self.update_led_indicator(1, True))
                        elif "LED1:OFF" in line:
                            self.led1_state = False
                            self.root.after(0, lambda: self.update_led_indicator(1, False))
                        
                        if "LED2:ON" in line:
                            self.led2_state = True
                            self.root.after(0, lambda: self.update_led_indicator(2, True))
                        elif "LED2:OFF" in line:
                            self.led2_state = False
                            self.root.after(0, lambda: self.update_led_indicator(2, False))
                            
            except Exception as e:
                print(f"Read error: {e}")
                break
            
            time.sleep(0.1)
    
    def celebrate_connection(self):
        """Fun animation when connected"""
        # Flash the status label
        self.flash_status_label(0, 6)
    
    def flash_status_label(self, step, max_steps):
        """Flash animation for status label"""
        if step < max_steps:
            color = "green" if step % 2 == 0 else "#00FF00"
            self.status_label.config(fg=color)
            self.root.after(100, lambda: self.flash_status_label(step + 1, max_steps))
        else:
            self.status_label.config(fg="green")
    
    def update_connection_status(self):
        """Update connection status periodically"""
        if self.is_connected and self.serial_port:
            if not self.serial_port.is_open:
                self.is_connected = False
                self.connect_btn.config(text="Connect 💕")
                self.status_label.config(text="● Disconnected", fg="red")
        
        self.root.after(1000, self.update_connection_status)

def main():
    root = tk.Tk()
    app = HelloKittyLEDController(root)
    root.mainloop()

if __name__ == "__main__":
    main()
