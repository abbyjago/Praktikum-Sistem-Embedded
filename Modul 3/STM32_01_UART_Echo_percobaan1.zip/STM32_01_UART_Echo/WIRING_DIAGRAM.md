# 📋 WIRING DIAGRAM - STM32 LED Control via UART/FTDI

## 🎯 Komponen yang Dibutuhkan

1. **STM32 BluePill (STM32F103C8T6)**
2. **FTDI USB to Serial Adapter** (FT232RL atau CH340)
3. **2x LED** (warna bebas, misalnya Merah dan Hijau)
4. **2x Resistor 220Ω - 330Ω** (untuk LED)
5. **2x Push Button** (Tactile switch) - BARU! 🆕
6. **Breadboard**
7. **Kabel Jumper**

---

## 🔌 Diagram Koneksi FTDI ke STM32

```
┌─────────────────────┐         ┌──────────────────────┐
│   FTDI Adapter      │         │   STM32 BluePill     │
│   (USB to Serial)   │         │                      │
│                     │         │                      │
│  VCC (3.3V) ────────┼─────────┤ 3.3V                 │
│                     │         │                      │
│  GND        ────────┼─────────┤ GND                  │
│                     │         │                      │
│  TX         ────────┼─────────┤ A10 (RX)             │
│                     │         │                      │
│  RX         ────────┼─────────┤ A9  (TX)             │
│                     │         │                      │
└─────────────────────┘         └──────────────────────┘
         │
         │ USB Cable
         │
         ▼
    Computer/Laptop
```

### ⚠️ PENTING - Koneksi UART:
- **FTDI TX** → **STM32 RX (A10)**
- **FTDI RX** → **STM32 TX (A9)**
- **FTDI GND** → **STM32 GND**
- **FTDI VCC (3.3V)** → **STM32 3.3V** (atau gunakan power dari ST-Link)

> **Catatan**: TX dari FTDI harus ke RX di STM32, dan sebaliknya!

---

## 💡 Diagram Koneksi LED

### LED 1 - Pin PC13 (LED Onboard)
```
┌──────────────────────┐
│   STM32 BluePill     │
│                      │
│  PC13 ───────────┐   │
│                  │   │
└──────────────────┼───┘
                   │
                   │   ┌─────┐
                   └───┤ LED │  (LED Onboard biasanya sudah ada)
                       │  ↓  │  (Biasanya sudah ada resistor built-in)
                       └──┬──┘
                          │
                         GND
```

### LED 2 - Pin PA5 (LED Eksternal)
```
┌──────────────────────┐
│   STM32 BluePill     │
│                      │
│  PA5 ────────────┐   │
│                  │   │
└──────────────────┼───┘
                   │
                   │
                  ┌┴┐
                  │ │  220Ω - 330Ω Resistor
                  └┬┘
                   │
                   │   ┌─────┐
                   └───┤ Anode (panjang)
                       │ LED │
                       │  ↓  │  
                   ┌───┤ Cathode (pendek)
                   │   └─────┘
                   │
                  GND
```

---

## 🔘 Diagram Koneksi Push Button (BARU! 🆕)

### Button 1 - Pin PB0 (untuk LED 1)
```
┌──────────────────────┐
│   STM32 BluePill     │
│                      │
│  PB0 ────────────┐   │
│                  │   │
│  3.3V (internal  │   │
│   pull-up)       │   │
└──────────────────┼───┘
                   │
                   │   ┌─────────┐
                   └───┤ Button 1│
                       │  (NO)   │
                   ┌───┤ Tactile │
                   │   └─────────┘
                   │
                  GND
```
PB0  PB1    PA5              │
         └───┬───────┬────┬──────┬───────────────┘
             │       │    │      │
             │    [BTN1][BTN2]   │
             │       │    │      │
        OnBoard     GND  GND ┌───┴────┐
         LED                 │ 220Ω   │
             │               └───┬────┘
             │                   │
             GND             ┌───┴────┐
                             │ LED 2  │  (Eksternal)
                             │ Anode  │
                             └───┬────┘
                                 │
                        └───┤ Button 2│
                       │  (NO)   │
                   ┌───┤ Tactile │
                   │   └─────────┘
                   │
                  GND
```

**Penjelasan Push Button:**
- Button menggunakan **INPUT_PULLUP** internal STM32
- Saat **tidak ditekan**: Pin baca HIGH (3.3V)
- Saat **ditekan**: Pin baca LOW (GND)
- **Tidak perlu resistor eksternal!** (pull-up sudah internal)
- Button = Tactile switch Normally Open (NO)

---

## 🔧 Wiring Lengkap (Breadboard Layout)

```
                    Computer
                       │
                       │ USB
                       ▼
              ┌────────────────┐
              │  FTDI Adapter  │
              │                │
              │ VCC GND TX RX  │
              └─┬───┬───┬───┬──┘
                │   │   │   │
    ────────────┼───┼───┼───┼─────────────────────
           3.3V │   │   │   │ A10(RX)  A9(TX)
                │   │   │   │    │        │
         ┌──────┴───┴───┼───┼────┴────────┴─────┐
         │  GND     GND │   │                    │
         │              │   │                    │
         │    STM32 BluePill F103C8              │
         │                                        │
         │  PC13           PA5                   │
         └───┬──────────────┬────────────────────┘
             │              │
             │              │
        OnBoard LED    ┌────┴────┐
             │         │ 220Ω    │
             │         └────┬────┘
             │              │
             GND        ┌───┴────┐
                        │ LED 2  │  (Eksternal)
                        │ Anode  │
                        └───┬────┘
                            │
                           GND


    Power Rail:  GND  ═══════════════════════════
                 3.3V ─────────────────────────────
```

---

## 📝 Langkah-Langkah Wiring Detail

### 1. Koneksi FTDI ke STM32 (UART Communication)

| FTDI Pin | STM32 Pin | Keterangan |
|----------|-----------|------------|
| VCC (3.3V) | 3.3V | Power supply 3.3V |
| GND | GND | Ground |
| TX | A10 | FTDI Transmit → STM32 Receive |
| RX | A9 | FTDI Receive → STM32 Transmit |

### 2. Koneksi LED 1 (Onboard LED)

**LED 1 menggunakan PC13** - biasanya sudah ada LED onboard di STM32 BluePill
- Pin PC13 sudah terhubung ke LED onboard
- Tidak perlu wiring tambahan
- Biasanya LED menyala saat pin LOW (active low)

> **Catatan**: Jika PC13 tidak memiliki LED onboard, hubungkan LED eksternal dengan resistor 220Ω

### 3. Koneksi LED 2 (LED Eksternal - PA5)

**Komponen:**
- 1x LED (warna bebas, misalnya Hijau)
- 1x Resistor 220Ω - 330Ω

**Langkah:**
1. Hubungkan **PA5** ke salah satu baris pada breadboard
2. Tambahkan **Resistor 220Ω** dari PA5
3. Hubungkan ujung resistor ke **Anode LED (kaki panjang)**
4. Hubungkan **Cathode LED (kaki pendek)** ke **GND**

```
STM32 PA5 ──→ [Resistor 220Ω] ──→ [LED Anode(+)] ──→ [LED Cathode(-)] ──→ GND
```
Koneksi Push Button 1 (PB0 - untuk LED 1) 🆕

**Komponen:**
- 1x Tactile Push Button (Normally Open)

**Langkah:**
1.Button 1 (satu kaki)
- Button 2 (satu kaki)
-  Hubungkan satu kaki button ke **PB0**
2. Hubungkan kaki lainnya ke **GND**
3. **Tidak perlu resistor!** (menggunakan internal pull-up)

```
STM32 PB0 ──→ [Button Pin 1] ──→ [Button Pin 2] ──→ GND
```

### 5. Koneksi Push Button 2 (PB1 - untuk LED 2) 🆕

**Komponen:**
- 1x Tactile Push Button (Normally Open)

**Langkah:**
1. Hubungkan satu kaki button ke **PB1**
2. Hubungkan kaki lainnya ke **GND**
3. **Tidak perlu resistor!** (menggunakan internal pull-up)

```
STM32 PB1 ──→ [Button Pin 1] ──→ [Button Pin 2] ──→ GND
```

### 6. 
### 4. Ground Connection (Penting!)

Pastikan semua ground terhubung:
- FTDI GND
- Button 1 | PB0 | Push button untuk LED 1 (dengan pull-up internal) 🆕 |
| Button 2 | PB1 | Push button untuk LED 2 (dengan pull-up internal) 🆕 |
| STM32 GND
- LED 2 Cathode
- **Semua harus terhubung ke ground rail yang sama!**

---

## 🔋 Power Supply Options

### Option 1: Power dari FTDI (Recommended untuk testing)
- Hubungkan FTDI VCC (3.3V) ke STM32 3.3V
- Arus mencukupi untuk STM32 + 2 LED

### Option 2: Power dari ST-Link (untuk programming)
- Gunakan ST-Link untuk power saat upload program
- FTDI hanya untuk komunikasi serial (tanpa VCC)

### Option 3: Power dari USB (BluePill langsung ke PC)
- Jika BluePill memiliki USB built-in
- Tetap butuh FTDI untuk komunikasi serial

---

## 🎯 Pin Summary STM32 BluePill

| Fungsi | Pin STM32 | Keterangan |
|--------|-----------|------------|
| UART TX | A9 | Serial transmit ke FTDI RX |
| UART RX | A10 | Serial receive dari FTDI TX |
| LED 1 | PC13 | LED onboard (atau eksternal) |
| LED 2 | PA5 | LED eksternal dengan resistor |
| Power | 3.3V | Power dari FTDI atau ST-Link |
| Ground | GND | Common ground |

---

## 🧪 Testing & Troubleshooting

### Tes Koneksi FTDI:
1. Upload program ke STM32 menggunakan ST-Link
2. Hubungkan FTDI ke komputer
3. Buka Device Manager → Ports: Cek COM port (misal COM3, COM5)
4. Jalankan Python GUI
5. Pilih COM port yang sesuai
6. Klik "Connect"

### Jika tidak terdeteksi:
- ✅ Pastikan driver FTDI terinstall (CP210x atau CH340 driver)
- ✅ Cek koneksi TX-RX (harus bersilang!)
- ✅ Pastikan baudrate 115200
- ✅ Cek GND terhubung

### Jika LED tidak menyala:
- ✅ Cek polaritas LED (anode ke resistor, cathode ke GND)
- ✅ Cek nilai resistor (220-330Ω)
- ✅ Pastikan pin PA5 dan PC13 sudah benar
- ✅ Test dengan multimeter untuk kontinuitas

---

## 📷 Foto Referensi Komponen

### STM32 BluePill Pinout
```
              USB
               │
         ┌─────┴─────┐
    VBAT │           │ GND
    PC13 │  ●     ●  │ GND
    PC14 │           │ 3V3
    PC15 │           │ NRST
     PA0 │           │ PB11
     PA1 │           │ PB10
     PA2 │    STM    │ PB1
     PA3 │    32F    │ PB0
     PA4 │   103C8   │ PA7
     PA5 │           │ PA6  ← LED 2 di sini
     PA6 │           │ PA5
     PA7 │           │ PA4
     PB0 │           │ PA3
     PB1 │           │ PA2
    PB10 │           │ PA1
    PB11 │           │ PA0
    NRST │           │ PC15
    3V3  │           │ PC14
     GND │  ●     ●  │ PC13 ← LED 1 (onboard)
     GND │           │ VBAT
         └───────────┘
          BOOT0 BOOT1
```

---

## 🚀 Cara Upload Program ke STM32

1. **Menggunakan ST-Link V2:**
   ```
   ST-Link      STM32
   ────────────────────
   3.3V    →    3.3V
   GND     →    GND
   SWDIO   →    SWDIO
   SWCLK   →    SWCLK
   ```

2. **Upload via PlatformIO:**
   - Buka project di VS Code
   - Tekan **Ctrl+Alt+U** atau klik icon Upload
   - Tunggu hingga "SUCCESS"

3. **Lepas ST-Link, Hubungkan FTDI**

---

## 💻 Cara Menjalankan GUI Python

1. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Jalankan GUI:**
   ```bash
   python led_controller_gui.py
   ```

3. **Gunakan GUI:**
   - Pilih COM port
   - Klik "Connect 💕"
   - Klik tombol LED untuk kontrol
   - LButton 1 terpasang di PB0 → GND 🆕
- [ ] Button 2 terpasang di PB1 → GND 🆕
- [ ] ihat indikator LED menyala di GUI

---

## 📡 Protocol Komunikasi

### Command dari Python ke STM32:
| Command | Fungsi |
|---------|--------|
| `1` | Toggle LED 1 |
| `2` | Toggle LED 2 |
| `S` atau `s` | Request status |

### Response dari STM32 ke Python:
| Response | Arti |
|----------|------|
| `LED1:ON` | LED 1 menyala |
| `LED1:OFF` | LED 1 mati |
| `LED2:ON` | LED 2 menyala |
| `LED2:OFF` | LED 2 mati |

---

## ✅ Checklist Sebelum Testing

- [ ] FTDI driver terinstall
- [ ] ST-Link terhubung untuk upload
- [ ] Program sudah di-upload ke STM32
- [ ] FTDI TX → STM32 RX (A10)
- [ ] FTDI RX → STM32 TX (A9)
- [ ] Ground FTDI dan STM32 terhubung
- [ ] LED 2 + Resistor terpasang di PA5
- [ ] Python dan pyserial terinstall
- [ ] COM port terdeteksi di Device Manager

---

## 🎉 Selamat! Sistem Anda Siap Digunakan!

Nikmati kontrol LED dengan tema Hello Kitty yang cute! 🎀💖✨
