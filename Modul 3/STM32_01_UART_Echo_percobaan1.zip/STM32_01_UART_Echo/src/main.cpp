#include <Arduino.h>

// LED Pins - Sesuaikan dengan pin STM32 Anda
#define LED1_PIN PC13  // LED onboard (biasanya)
#define LED2_PIN PA5   // LED eksternal

// Push Button Pins (Eksternal)
#define BTN1_PIN PB0   // Button untuk LED 1
#define BTN2_PIN PB1   // Button untuk LED 2

// Status LED
bool led1_state = false;
bool led2_state = false;

// Button states untuk debouncing
bool btn1_last_state = HIGH;
bool btn2_last_state = HIGH;
bool btn1_current_stable = HIGH;
bool btn2_current_stable = HIGH;
unsigned long btn1_last_debounce = 0;
unsigned long btn2_last_debounce = 0;
const unsigned long debounce_delay = 50;  // 50ms debounce

void setup() {
    // Inisialisasi Serial
    Serial.begin(115200);
    delay(2000);
    Serial.println("=== STM32 LED Control via UART ===");
    Serial.println("Commands:");
    Serial.println("  1 = Toggle LED 1");
    Serial.println("  2 = Toggle LED 2");
    Serial.println("  S = Status LEDs");
    Serial.println("Push Button controls also active!");
    Serial.println("================================\n");
    
    // Setup LED pins sebagai output
    pinMode(LED1_PIN, OUTPUT);
    pinMode(LED2_PIN, OUTPUT);
    
    // Setup Button pins sebagai input dengan pull-up
    pinMode(BTN1_PIN, INPUT_PULLUP);
    pinMode(BTN2_PIN, INPUT_PULLUP);
    
    // Matikan semua LED di awal
    digitalWrite(LED1_PIN, LOW);
    digitalWrite(LED2_PIN, LOW);
    
    // Test button pins
    Serial.println("\n=== Button Pin Test ===");
    Serial.print("BTN1 (PB0) initial state: ");
    Serial.println(digitalRead(BTN1_PIN) ? "HIGH (not pressed)" : "LOW (pressed)");
    Serial.print("BTN2 (PB1) initial state: ");
    Serial.println(digitalRead(BTN2_PIN) ? "HIGH (not pressed)" : "LOW (pressed)");
    Serial.println("======================\n");
}

void toggleLED1() {
    led1_state = !led1_state;
    digitalWrite(LED1_PIN, led1_state ? HIGH : LOW);
    Serial.print("LED1:");
    Serial.println(led1_state ? "ON" : "OFF");
}

void toggleLED2() {
    led2_state = !led2_state;
    digitalWrite(LED2_PIN, led2_state ? HIGH : LOW);
    Serial.print("LED2:");
    Serial.println(led2_state ? "ON" : "OFF");
}

void checkButtons() {
    // Check Button 1 (dengan debouncing)
    bool btn1_reading = digitalRead(BTN1_PIN);
    
    // Reset debounce timer jika state berubah
    if (btn1_reading != btn1_last_state) {
        btn1_last_debounce = millis();
        Serial.print("BTN1 changed: ");
        Serial.println(btn1_reading ? "HIGH" : "LOW");
    }
    
    // Cek apakah sudah stabil selama debounce_delay
    if ((millis() - btn1_last_debounce) > debounce_delay) {
        // State sudah stabil, cek apakah ada perubahan dari stable state
        if (btn1_reading != btn1_current_stable) {
            btn1_current_stable = btn1_reading;
            
            // Detect button press (transisi HIGH -> LOW)
            if (btn1_current_stable == LOW) {
                Serial.println("BTN1 PRESSED! Toggling LED1...");
                toggleLED1();
            }
        }
    }
    
    btn1_last_state = btn1_reading;
    
    // Check Button 2 (dengan debouncing)
    bool btn2_reading = digitalRead(BTN2_PIN);
    
    // Reset debounce timer jika state berubah
    if (btn2_reading != btn2_last_state) {
        btn2_last_debounce = millis();
        Serial.print("BTN2 changed: ");
        Serial.println(btn2_reading ? "HIGH" : "LOW");
    }
    
    // Cek apakah sudah stabil selama debounce_delay
    if ((millis() - btn2_last_debounce) > debounce_delay) {
        // State sudah stabil, cek apakah ada perubahan dari stable state
        if (btn2_reading != btn2_current_stable) {
            btn2_current_stable = btn2_reading;
            
            // Detect button press (transisi HIGH -> LOW)
            if (btn2_current_stable == LOW) {
                Serial.println("BTN2 PRESSED! Toggling LED2...");
                toggleLED2();
            }
        }
    }
    
    btn2_last_state = btn2_reading;
}

void loop() {
    // Check physical buttons
    checkButtons();
    
    // Check UART commands from GUI
    if (Serial.available()) {
        char command = Serial.read();
        
        switch(command) {
            case '1':  // Toggle LED 1 from GUI
                toggleLED1();
                break;
                
            case '2':  // Toggle LED 2 from GUI
                toggleLED2();
                break;
                
            case 'S':  // Status request
            case 's':
                Serial.print("LED1:");
                Serial.print(led1_state ? "ON" : "OFF");
                Serial.print(",LED2:");
                Serial.println(led2_state ? "ON" : "OFF");
                break;
                
            default:
                // Echo karakter lain
                Serial.print("Unknown command: ");
                Serial.println(command);
                break;
        }
    }
}
