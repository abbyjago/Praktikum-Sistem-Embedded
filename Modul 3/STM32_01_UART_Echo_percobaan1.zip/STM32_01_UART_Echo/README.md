# 🎀 STM32 LED Controller dengan Hello Kitty GUI 💖

Proyek ini adalah sistem kontrol LED STM32 melalui komunikasi UART/FTDI dengan GUI Python bertema Hello Kitty yang cute!

## 📁 File-file dalam Project

```
STM32_01_UART_Echo/
├── src/
│   └── main.cpp                    # Program STM32 untuk kontrol LED
├── platformio.ini                  # Konfigurasi PlatformIO
├── led_controller_gui.py           # GUI Python dengan tema Hello Kitty
├── requirements.txt                # Dependencies Python
├── WIRING_DIAGRAM.md              # Diagram wiring lengkap
└── README.md                       # File ini
```

## ✨ Fitur

- 🎮 Kontrol 2 LED via GUI Python
- � Kontrol 2 LED via Push Button Fisik Eksternal 🆕
- 💕 Tema Hello Kitty yang cute dan colorful
- 💡 Indikator LED real-time di GUI (sync otomatis!)
- 🔌 Komunikasi UART 115200 baud
- 🎨 Interface user-friendly dengan Comic Sans MS
- ⚡ Debouncing otomatis untuk button fisik

## 🚀 Quick Start

### 1️⃣ Upload Program ke STM32

1. Buka project ini di VS Code dengan PlatformIO
2. Hubungkan ST-Link ke STM32
3. Tekan **Ctrl+Alt+U** untuk upload
4. Tunggu hingga sukses

### 2️⃣ Setup Hardware

Lihat file [WIRING_DIAGRAM.md](WIRING_DIAGRAM.md) untuk detail lengkap!

**Koneksi singkat:**
- FTDI TX → STM32 A10 (RX)
- FTDI RX → STM32 A9 (TX)
- FTDI GND → STM32 GND
- LED 1 di pin PC13 (onboard)
- LED 2 di pin PA5 (eksternal + resistor 220Ω)
- Button 1 di pin PB0 → GND (untuk LED 1) 🆕
- Button 2 di pin PB1 → GND (untuk LED 2) 🆕

### 3️⃣ Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 4️⃣ Jalankan GUI

```bash
python led_controller_gui.py
```

**Ada 2 cara kontrol LED:**

**Cara 1: Via GUI Python** 
1. Pilih COM port dari dropdown
2. Klik **"Connect 💕"**
3. Klik tombol **"🎀 Toggle LED 1 🎀"** atau **"🌸 Toggle LED 2 🌸"**
4. Lihat LED menyala di STM32 dan indikator di GUI!

**Cara 2: Via Push Button Fisik** 🆕
1. Tekan **Button 1** (PB0) → LED 1 toggle & indikator GUI update otomatis!
2. Tekan **Button 2** (PB1) → LED 2 toggle & indikator GUI update otomatis!

> **Keduanya sinkron!** Button mana pun yang ditekan (GUI atau fisik), indikator GUI akan update otomatis! ✨
3. Klik tombol **"🎀 Toggle LED 1 🎀"** atau **"🌸 Toggle LED 2 🌸"**
4. Lihat LED menyala di STM32 dan indikator di GUI!

## 📡 Komunikasi Protocol

### Command (Python → STM32):
- `1` = Toggle LED 1
- `2` = Toggle LED 2  
- `S` = Request status

### Response (STM32 → Python):
- `LED1:ON` / `LED1:OFF`
- `LED2:ON` / `LED2:OFF`

## 🎨 Screenshot GUI

GUI menampilkan:
- 💖 Background pink dengan tema Hello Kitty
- 🎀 2 tombol kontrol LED yang cute
- 💡 Indikator LED visual (menyala/mati)
- 🔌 Status koneksi real-time
- ✨ Font Comic Sans MS untuk kesan playful

## 🛠️ Troubleshooting

### COM Port tidak terdeteksi?
- Install driver FTDI (CH340 atau FT232 driver)
- Cek Device Manager → Ports
- Klik tombol refresh (🔄) di GUI

### LED tidak menyala?
- Cek polaritas LED (anode ke resistor, cathode ke GND)
- Pastikan resistor 220-330Ω terpasang
- Verifikasi wiring sesuai diagram

### Tidak bisa connect?
- Pastikan baudrate 115200
- Cek TX-RX bersilang (TX FTDI → RX STM32)
- Pastikan GND terhubung
- Restart STM32 setelah connect

## 📚 Referensi

- **STM32 Board**: BluePill STM32F103C8T6
- **Framework**: Arduino for STM32
- **Python**: tkinter + pyserial
- **Upload**: ST-Link V2
- **Communication**: FTDI USB to Serial

## 💖 Credits

Made with love and Hello Kitty cuteness! 🎀✨

---

**Enjoy controlling your LEDs with kawaii style!** 🌸💕

