@echo off
title Hello Kitty LED Controller
echo.
echo ======================================
echo   Starting Hello Kitty LED Controller
echo ======================================
echo.
echo Checking Python installation...
python --version
if errorlevel 1 (
    echo ERROR: Python not found!
    echo Please install Python first.
    pause
    exit /b 1
)
echo.
echo Installing dependencies...
pip install -r requirements.txt
echo.
echo ======================================
echo   Launching GUI...
echo ======================================
echo.
python led_controller_gui.py
pause
