# 🔘 Fitur Push Button Eksternal - Penjelasan

## 🎯 Cara Kerja Sistem

Sistem ini memiliki **2 metode kontrol LED** yang **sinkron sempurna**:

### 1️⃣ Kontrol via GUI Python (Remote)
- Klik button di GUI
- Kirim command via UART
- STM32 toggle LED
- STM32 kirim status ke GUI
- Indikator GUI update

### 2️⃣ Kontrol via Push Button Fisik (Lokal) 🆕
- Tekan button fisik di breadboard
- STM32 deteksi button press
- STM32 toggle LED
- STM32 kirim status ke GUI
- Indikator GUI update **otomatis!**

## 🔄 Sinkronisasi Otomatis

**Skenario 1: Tekan button GUI**
```
GUI Button → UART → STM32 → Toggle LED → UART → GUI Update ✅
```

**Skenario 2: Tekan button fisik**
```
Physical Button → STM32 → Toggle LED → UART → GUI Update ✅
```

**Hasilnya:**
- ✅ LED fisik selalu sinkron dengan indikator GUI
- ✅ Tidak peduli button mana yang ditekan
- ✅ GUI selalu tahu status LED real-time

## 🔧 Wiring Push Button

### Button 1 (untuk LED 1):
```
STM32 PB0 ──┬──→ [Button Pin 1]
            │
    (Pull-up internal 3.3V)
            
            └──→ [Button Pin 2] ──→ GND
```

### Button 2 (untuk LED 2):
```
STM32 PB1 ──┬──→ [Button Pin 1]
            │
    (Pull-up internal 3.3V)
            
            └──→ [Button Pin 2] ──→ GND
```

### Cara Kerja:
- **Tidak ditekan**: Pin baca HIGH (3.3V via pull-up)
- **Ditekan**: Pin baca LOW (GND via button)
- **Debouncing**: 50ms delay mencegah bouncing

## 🎨 Visual Diagram

```
┌─────────────────────────────────────────────┐
│                                             │
│  [GUI Button 1] ─────┐                     │
│                       │                     │
│                       ▼                     │
│                   ┌────────┐                │
│  [Physical BTN1]─→│  LED1  │ ←─ PC13       │
│                   └────────┘                │
│                       │                     │
│                       ▼                     │
│                 [Status: ON/OFF]            │
│                       │                     │
│                       ▼                     │
│                 [GUI Indicator 1]           │
│                                             │
│  - - - - - - - - - - - - - - - - - - - - - │
│                                             │
│  [GUI Button 2] ─────┐                     │
│                       │                     │
│                       ▼                     │
│                   ┌────────┐                │
│  [Physical BTN2]─→│  LED2  │ ←─ PA5        │
│                   └────────┘                │
│                       │                     │
│                       ▼                     │
│                 [Status: ON/OFF]            │
│                       │                     │
│                       ▼                     │
│                 [GUI Indicator 2]           │
│                                             │
└─────────────────────────────────────────────┘
```

## 💡 Keuntungan Sistem Ini

1. **Dual Mode Control**
   - Remote: Kontrol dari PC via GUI
   - Local: Kontrol langsung di breadboard

2. **Real-time Sync**
   - Indikator selalu update
   - Tidak ada delay signifikan

3. **Debouncing**
   - Tidak ada bouncing effect
   - 50ms debounce time

4. **User Friendly**
   - Tekan button mana saja
   - Sistem otomatis sinkron

## 🧪 Testing

### Test 1: GUI Control
1. Buka GUI, connect ke STM32
2. Klik button GUI "Toggle LED 1"
3. **Expected**: LED fisik nyala, indikator GUI berubah pink

### Test 2: Physical Button
1. GUI tetap connect
2. Tekan button fisik (BTN1 atau BTN2)
3. **Expected**: LED fisik nyala, indikator GUI **otomatis** berubah pink

### Test 3: Mixed Control
1. Klik GUI → LED ON
2. Tekan button fisik → LED OFF
3. Klik GUI lagi → LED ON
4. **Expected**: Semua transisi smooth, indikator selalu tepat

## 🔍 Debug Tips

### LED tidak nyala saat tekan button fisik?
- ✅ Cek wiring button: PB0/PB1 → Button → GND
- ✅ Pastikan button Normally Open (NO)
- ✅ Test dengan multimeter: cek kontinuitas saat ditekan

### Indikator GUI tidak update?
- ✅ Pastikan GUI dalam mode "Connected"
- ✅ Cek serial monitor: apakah ada print "LED1:ON" ?
- ✅ Restart GUI

### Button bouncing (LED flicker)?
- ✅ Sudah ada debouncing 50ms di code
- ✅ Jika masih bouncing, naikkan delay jadi 100ms
- ✅ Ganti button dengan kualitas lebih baik

## 📊 Pin Configuration Summary

| Item | Pin STM32 | Mode | Notes |
|------|-----------|------|-------|
| LED 1 | PC13 | OUTPUT | Onboard LED |
| LED 2 | PA5 | OUTPUT | External + 220Ω |
| Button 1 | PB0 | INPUT_PULLUP | Toggle LED 1 |
| Button 2 | PB1 | INPUT_PULLUP | Toggle LED 2 |
| UART TX | A9 | Serial | Ke FTDI RX |
| UART RX | A10 | SERIAL | Dari FTDI TX |

## 🎉 Selamat!

Sekarang kamu punya sistem kontrol LED dengan:
- ✨ GUI cute Hello Kitty theme
- 🔘 Push button fisik eksternal
- 🔄 Sinkronisasi sempurna
- 💡 Indikator real-time

Enjoy your project! 🎀💖
