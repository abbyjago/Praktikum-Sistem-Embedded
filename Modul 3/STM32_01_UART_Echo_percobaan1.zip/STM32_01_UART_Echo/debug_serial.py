"""
Debug Script - Test Serial Communication STM32
Untuk debugging masalah button eksternal
"""

import serial
import serial.tools.list_ports
import time

def list_ports():
    """List all available COM ports"""
    print("\n=== Available COM Ports ===")
    ports = serial.tools.list_ports.comports()
    for i, port in enumerate(ports):
        print(f"{i+1}. {port.device} - {port.description}")
    return [port.device for port in ports]

def test_serial(port_name):
    """Test serial communication"""
    print(f"\n=== Connecting to {port_name} ===")
    try:
        ser = serial.Serial(port_name, 115200, timeout=1)
        time.sleep(2)  # Wait for Arduino reset
        print("✅ Connected successfully!")
        
        print("\n=== Reading data (Press Ctrl+C to stop) ===")
        print("Tekan push button fisik di STM32 dan lihat output di sini!\n")
        
        while True:
            if ser.in_waiting:
                line = ser.readline().decode('utf-8', errors='ignore').strip()
                if line:
                    print(f"📩 Received: '{line}'")
                    
                    # Check format
                    if "LED1:ON" in line or "LED1:OFF" in line:
                        print("   ✅ LED1 status detected!")
                    elif "LED2:ON" in line or "LED2:OFF" in line:
                        print("   ✅ LED2 status detected!")
                    else:
                        print("   ⚠️ Unknown format")
            
            time.sleep(0.1)
            
    except KeyboardInterrupt:
        print("\n\n=== Stopped by user ===")
        ser.close()
    except Exception as e:
        print(f"❌ Error: {e}")

def main():
    print("=" * 50)
    print("  STM32 Serial Debug Tool")
    print("=" * 50)
    
    ports = list_ports()
    
    if not ports:
        print("\n❌ No COM ports found!")
        print("Pastikan:")
        print("  - FTDI terhubung ke laptop")
        print("  - Driver FTDI sudah terinstall")
        return
    
    print("\nPilih COM port (masukkan nomor): ", end="")
    try:
        choice = int(input()) - 1
        if 0 <= choice < len(ports):
            test_serial(ports[choice])
        else:
            print("❌ Pilihan tidak valid!")
    except ValueError:
        print("❌ Input harus berupa nomor!")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()
