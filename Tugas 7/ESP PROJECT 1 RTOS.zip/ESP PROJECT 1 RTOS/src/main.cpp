/* ============================================================
 * ESP32 FreeRTOS Task dengan LED, DHT22, dan Servo SG90
 * ============================================================
 * Program ini mendemonstrasikan tiga task FreeRTOS:
 * 1. Task LED: Mengontrol LED dengan informasi timestamp, state, counter, core
 * 2. Task DHT22: Membaca sensor DHT22 dengan informasi suhu, kelembaban, counter
 * 3. Task Servo: Mengontrol SG90 dengan informasi angle, counter, core
 *
 * Tekan tombol BOOT (GPIO 0) untuk menghentikan semua task
 * Output ditampilkan di Serial Monitor dengan format rapi
 * ============================================================ */

#include <Arduino.h>
#include <DHT.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

/* Definisi GPIO */
#define LED_GPIO         2
#define DHT_GPIO         4
#define SERVO_GPIO      13  // Gunakan pin non-strapping untuk servo
#define BOOT_BUTTON_GPIO 0

/* Servo PWM */
#define SERVO_CHANNEL   0
#define SERVO_FREQ     50
#define SERVO_RES      12

/* DHT object */
DHT dht(DHT_GPIO, DHT22);

/* Task handles */
static TaskHandle_t xLedTaskHandle = NULL;
static TaskHandle_t xDhtTaskHandle = NULL;
static TaskHandle_t xServoTaskHandle = NULL;

/* Counter untuk tracking */
static volatile uint32_t led_counter = 0;
static volatile uint32_t dht_counter = 0;
static volatile uint32_t servo_counter = 0;

/* Stop flag */
static volatile bool stop_requested = false;

static inline bool boot_button_pressed() {
    return digitalRead(BOOT_BUTTON_GPIO) == LOW;
}

static inline uint32_t angle_to_duty(uint32_t angle) {
    // Gunakan range duty lebih lebar untuk SG90 yang berbeda-beda
    // 0° -> sekitar 0.5 ms, 180° -> sekitar 2.5 ms pada 50Hz dan 12-bit
    return map(angle, 0, 180, 102, 512);
}

/* ============================================================
 * TASK LED
 * ============================================================ */
void led_task(void *pvParameters) {
    pinMode(LED_GPIO, OUTPUT);

    bool led_state = false;

    while (!stop_requested) {
        led_state = !led_state;
        digitalWrite(LED_GPIO, led_state);

        uint32_t timestamp = millis();
        int core_id = xPortGetCoreID();
        led_counter++;

        Serial.printf("LED Task  | %7lums | State=%s | Count=%4lu | Core=%d\n",
                      timestamp,
                      led_state ? "ON" : "OFF",
                      led_counter,
                      core_id);

        vTaskDelay(pdMS_TO_TICKS(1000));
    }

    digitalWrite(LED_GPIO, LOW);
    Serial.printf("LED Task  | %7lums | State=STOP | Count=%4lu | Core=%d\n",
                  millis(), led_counter, xPortGetCoreID());
    vTaskDelete(NULL);
}

/* ============================================================
 * TASK DHT22
 * ============================================================ */
void dht_task(void *pvParameters) {
    while (!stop_requested) {
        float temperature = dht.readTemperature();
        float humidity = dht.readHumidity();

        dht_counter++;

        if (!isnan(temperature) && !isnan(humidity)) {
            Serial.printf("DHT22 Task | %7lums | Temp=%5.1fC | Hum=%5.1f%% | Count=%4lu\n",
                          millis(), temperature, humidity, dht_counter);
        } else {
            Serial.printf("DHT22 Task | %7lums | Temp=ERROR | Hum=---- | Count=%4lu\n",
                          millis(), dht_counter);
        }

        vTaskDelay(pdMS_TO_TICKS(2000));
    }

    Serial.printf("DHT22 Task | %7lums | State=STOP | Count=%4lu\n",
                  millis(), dht_counter);
    vTaskDelete(NULL);
}

/* ============================================================
 * TASK SERVO SG90
 * ============================================================ */
void servo_task(void *pvParameters) {
    pinMode(SERVO_GPIO, OUTPUT);
    ledcSetup(SERVO_CHANNEL, SERVO_FREQ, SERVO_RES);
    ledcAttachPin(SERVO_GPIO, SERVO_CHANNEL);

    uint32_t angle = 0;
    bool increasing = true;

    while (!stop_requested) {
        uint32_t duty = angle_to_duty(angle);
        ledcWrite(SERVO_CHANNEL, duty);

        servo_counter++;
        Serial.printf("Servo Task | %7lums | Angle=%3lu | Duty=%4lu | Count=%4lu | Core=%d\n",
                      millis(), angle, duty, servo_counter, xPortGetCoreID());

        if (increasing) {
            angle += 45;
            if (angle >= 180) {
                angle = 180;
                increasing = false;
            }
        } else {
            angle -= 45;
            if (angle == 0) {
                increasing = true;
            }
        }

        vTaskDelay(pdMS_TO_TICKS(1000));
    }

    ledcWrite(SERVO_CHANNEL, angle_to_duty(90));
    Serial.printf("Servo Task | %7lums | State=STOP | Count=%4lu | Core=%d\n",
                  millis(), servo_counter, xPortGetCoreID());
    vTaskDelete(NULL);
}

/* ============================================================
 * SETUP FUNCTION (Arduino style)
 * ============================================================ */
void setup() {
    Serial.begin(115200);
    delay(1000); // Tunggu serial ready

    pinMode(BOOT_BUTTON_GPIO, INPUT_PULLUP);

    Serial.println("==========================================");
    Serial.println("ESP32 FreeRTOS Tasks Demo");
    Serial.println("LED + DHT22 + Servo SG90");
    Serial.println("Tiga tasks: LED, DHT22, Servo");
    Serial.println("Tekan tombol BOOT untuk menghentikan program");
    Serial.println("==========================================");
    Serial.println();

    dht.begin();

    xTaskCreate(
        led_task,
        "LED_Task",
        2048,
        NULL,
        1,
        &xLedTaskHandle
    );

    xTaskCreate(
        dht_task,
        "DHT_Task",
        4096,
        NULL,
        1,
        &xDhtTaskHandle
    );

    xTaskCreate(
        servo_task,
        "Servo_Task",
        4096,
        NULL,
        1,
        &xServoTaskHandle
    );

    Serial.println("▶️  Tasks started - Press BOOT button to stop");
}

/* ============================================================
 * LOOP FUNCTION (Arduino style): memeriksa tombol BOOT
 * ============================================================ */
void loop() {
    if (!stop_requested && boot_button_pressed()) {
        stop_requested = true;
        Serial.println("⚠️  BOOT button ditekan - menghentikan semua task...");
    }

    if (stop_requested) {
        vTaskDelay(pdMS_TO_TICKS(100));
        return;
    }

    vTaskDelay(pdMS_TO_TICKS(100));
}
