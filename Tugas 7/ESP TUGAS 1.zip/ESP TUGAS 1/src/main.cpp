/* ============================================================
 * ESP32 FreeRTOS Task dengan LED dan DHT22
 * ============================================================
 * Program ini mendemonstrasikan dua task FreeRTOS:
 * 1. Task LED: Mengontrol LED dengan informasi timestamp, state, counter, core
 * 2. Task DHT22: Membaca sensor DHT22 dengan informasi suhu, kelembaban, counter
 *
 * Tekan tombol BOOT (GPIO 0) untuk menghentikan program
 * Output ditampilkan di Serial Monitor dengan format rapi
 * ============================================================ */

#include <Arduino.h>
#include <DHT.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

/* Tag untuk logging */
#define TAG "ESP32_TASKS"

/* Definisi GPIO */
#define LED_GPIO    2
#define DHT_GPIO    4

/* DHT object */
DHT dht(DHT_GPIO, DHT22);

/* Task handles */
static TaskHandle_t xLedTaskHandle = NULL;
static TaskHandle_t xDhtTaskHandle = NULL;

/* Counter untuk tracking */
static volatile uint32_t led_counter = 0;
static volatile uint32_t dht_counter = 0;

/* ============================================================
 * TASK LED
 * ============================================================ */
void led_task(void *pvParameters) {
    /* Konfigurasi GPIO untuk LED */
    pinMode(LED_GPIO, OUTPUT);

    bool led_state = false;

    while (1) {
        /* Toggle LED */
        led_state = !led_state;
        digitalWrite(LED_GPIO, led_state);

        /* Dapatkan informasi */
        uint32_t timestamp = millis();
        int core_id = xPortGetCoreID();
        led_counter++;

        /* Print ke Serial Monitor dengan format rapi */
        Serial.printf("LED Task  | %7lums | State=%s | Count=%4lu | Core=%d\n",
                      timestamp,
                      led_state ? "ON" : "OFF",
                      led_counter,
                      core_id);

        /* Delay 1 detik */
        vTaskDelay(pdMS_TO_TICKS(1000));
    }

    /* Cleanup */
    digitalWrite(LED_GPIO, LOW);
    Serial.printf("LED Task  | %7lums | State=STOP | Count=%4lu | Core=%d\n",
                  millis(), led_counter, xPortGetCoreID());
    vTaskDelete(NULL);
}

/* ============================================================
 * TASK DHT22
 * ============================================================ */
void dht_task(void *pvParameters) {
    while (1) {
        /* Baca sensor DHT22 */
        float temperature = dht.readTemperature();
        float humidity = dht.readHumidity();

        dht_counter++;

        if (!isnan(temperature) && !isnan(humidity)) {
            /* Print ke Serial Monitor dengan format rapi */
            Serial.printf("DHT22 Task | %7lums | Temp=%5.1fC | Hum=%5.1f%% | Count=%4lu\n",
                          millis(), temperature, humidity, dht_counter);
        } else {
            Serial.printf("DHT22 Task | %7lums | Temp=ERROR | Hum=---- | Count=%4lu\n",
                          millis(), dht_counter);
        }

        /* Delay 2 detik */
        vTaskDelay(pdMS_TO_TICKS(2000));
    }

    vTaskDelete(NULL);
}

/* ============================================================
 * SETUP FUNCTION (Arduino style)
 * ============================================================ */
void setup() {
    /* Inisialisasi Serial */
    Serial.begin(115200);
    delay(1000); // Tunggu serial ready

    /* Header program */
    Serial.println("==========================================");
    Serial.println("ESP32 FreeRTOS Tasks Demo");
    Serial.println("LED + DHT22 Sensor");
    Serial.println("Two tasks: LED and DHT22");
    Serial.println("==========================================");
    Serial.println();

    /* Inisialisasi DHT */
    dht.begin();

    /* Buat task LED */
    xTaskCreate(
        led_task,           // Function
        "LED_Task",         // Name
        2048,               // Stack size
        NULL,               // Parameters
        1,                  // Priority
        &xLedTaskHandle     // Handle
    );

    /* Buat task DHT22 */
    xTaskCreate(
        dht_task,           // Function
        "DHT_Task",         // Name
        4096,               // Stack size (lebih besar untuk DHT)
        NULL,               // Parameters
        1,                  // Priority
        &xDhtTaskHandle     // Handle
    );

    Serial.println("▶️  Tasks started - Press BOOT button to stop");
}

/* ============================================================
 * LOOP FUNCTION (tidak digunakan karena menggunakan FreeRTOS tasks)
 * ============================================================ */
void loop() {
    /* Kosong - semua logic di tasks */
    vTaskDelay(pdMS_TO_TICKS(1000));
}
