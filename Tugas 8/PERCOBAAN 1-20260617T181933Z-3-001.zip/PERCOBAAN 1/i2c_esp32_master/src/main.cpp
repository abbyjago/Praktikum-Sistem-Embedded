#include <Arduino.h>
#include <Wire.h>
#include "config.h"

static unsigned long lastSendMs = 0;

void setup() {
    Serial.begin(115200);
    delay(1500);

    Serial.println("ESP32 I2C master start");

    Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
    Wire.setClock(I2C_SPEED_HZ);

    Serial.printf("I2C SDA=%d SCL=%d speed=%lu Hz\n",
                  I2C_SDA_PIN, I2C_SCL_PIN, (unsigned long)I2C_SPEED_HZ);
}

void loop() {
    unsigned long now = millis();
    if (now - lastSendMs >= SEND_INTERVAL_MS) {
        lastSendMs = now;

        const char *msg = MESSAGE_TEXT;
        Wire.beginTransmission(I2C_SLAVE_ADDR);
        Wire.write(reinterpret_cast<const uint8_t *>(msg), strlen(msg));
        uint8_t result = Wire.endTransmission(true);

        if (result == 0) {
            Serial.printf("Sent: %s\n", msg);
        } else {
            Serial.printf("I2C error: %u\n", result);
        }
    }

    delay(10);
}
