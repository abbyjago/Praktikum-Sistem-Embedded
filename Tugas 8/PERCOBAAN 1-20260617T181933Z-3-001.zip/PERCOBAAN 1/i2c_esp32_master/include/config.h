#ifndef CONFIG_H
#define CONFIG_H

#define I2C_SPEED_HZ        100000
#define SEND_INTERVAL_MS    1000
#define MESSAGE_TEXT        "helloworld"

#endif // CONFIG_H
