from datetime import datetime

Import("env")

def before_build(source, target, env):
    build_date = datetime.now().strftime("%Y-%m-%d")
    env.Append(CPPDEFINES=[("BUILD_DATE", '\"%s\"' % build_date)])

env.AddPreAction("buildprog", before_build)
