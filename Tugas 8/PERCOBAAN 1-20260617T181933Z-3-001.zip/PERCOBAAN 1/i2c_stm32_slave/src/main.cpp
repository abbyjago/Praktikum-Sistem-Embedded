#include <Arduino.h>
#include <Wire.h>
#include "config.h"

// ==================== LCD DRIVER (PCF8574) ====================
class I2cLcd {
public:
    I2cLcd(TwoWire &wire, uint8_t addr, uint8_t cols, uint8_t rows)
        : _wire(wire), _addr(addr), _cols(cols), _rows(rows) {}

    void begin() {
        delay(50);
        write4Bits(0x30, 0);
        delay(5);
        write4Bits(0x30, 0);
        delayMicroseconds(150);
        write4Bits(0x30, 0);
        delayMicroseconds(150);
        write4Bits(0x20, 0);

        command(0x28); // 4-bit, 2-line, 5x8 dots
        command(0x08); // display off
        command(0x01); // clear
        delay(2);
        command(0x06); // entry mode
        command(0x0C); // display on, cursor off
    }

    void clear() {
        command(0x01);
        delay(2);
    }

    void setCursor(uint8_t col, uint8_t row) {
        static const uint8_t rowOffsets[] = {0x00, 0x40, 0x14, 0x54};
        if (row >= _rows) {
            row = _rows - 1;
        }
        command(0x80 | (col + rowOffsets[row]));
    }

    void writeChar(char value) {
        send(value, PIN_RS);
    }

private:
    void command(uint8_t value) {
        send(value, 0);
    }

    void send(uint8_t value, uint8_t mode) {
        write4Bits(value & 0xF0, mode);
        write4Bits((value << 4) & 0xF0, mode);
    }

    void write4Bits(uint8_t value, uint8_t mode) {
        uint8_t data = value | _backlight | mode;
        expanderWrite(data);
        pulseEnable(data);
    }

    void expanderWrite(uint8_t data) {
        _wire.beginTransmission(_addr);
        _wire.write(data);
        _wire.endTransmission();
    }

    void pulseEnable(uint8_t data) {
        expanderWrite(data | PIN_EN);
        delayMicroseconds(1);
        expanderWrite(data & ~PIN_EN);
        delayMicroseconds(50);
    }

    TwoWire &_wire;
    uint8_t _addr;
    uint8_t _cols;
    uint8_t _rows;
    uint8_t _backlight = PIN_BACKLIGHT;

    static constexpr uint8_t PIN_RS = 0x01;
    static constexpr uint8_t PIN_RW = 0x02;
    static constexpr uint8_t PIN_EN = 0x04;
    static constexpr uint8_t PIN_BACKLIGHT = 0x08;
};

// ==================== I2C SLAVE RX ====================
static volatile bool msgReady = false;
static volatile uint8_t msgLen = 0;
static char msgBuf[MSG_BUF_SIZE];

TwoWire Wire1(I2C2_SDA_PIN, I2C2_SCL_PIN);
I2cLcd lcd(Wire1, LCD_ADDR, LCD_COLS, LCD_ROWS);

void onReceiveHandler(int count) {
    uint8_t idx = 0;
    while (Wire.available() && idx < (MSG_BUF_SIZE - 1)) {
        msgBuf[idx++] = static_cast<char>(Wire.read());
    }
    msgBuf[idx] = '\0';
    msgLen = idx;
    msgReady = true;

    while (Wire.available()) {
        Wire.read();
    }
}

void renderMessage(const char *msg) {
    lcd.clear();

    uint8_t row = 0;
    uint8_t col = 0;
    lcd.setCursor(0, 0);

    for (size_t i = 0; msg[i] != '\0' && row < LCD_ROWS; ++i) {
        if (msg[i] == '\n') {
            row++;
            col = 0;
            if (row < LCD_ROWS) {
                lcd.setCursor(col, row);
            }
            continue;
        }

        lcd.writeChar(msg[i]);
        col++;
        if (col >= LCD_COLS) {
            row++;
            col = 0;
            if (row < LCD_ROWS) {
                lcd.setCursor(col, row);
            }
        }
    }
}

void setup() {
    Serial.begin(SERIAL_BAUD);
    delay(1500);

    Serial.println("STM32 I2C slave + LCD start");

    Wire.setSDA(I2C1_SDA_PIN);
    Wire.setSCL(I2C1_SCL_PIN);
    Wire.begin(I2C_SLAVE_ADDR);
    Wire.setClock(I2C_SLAVE_SPEED_HZ);
    Wire.onReceive(onReceiveHandler);

    Wire1.begin();
    Wire1.setClock(LCD_I2C_SPEED_HZ);

    lcd.begin();
    lcd.clear();
    lcd.setCursor(0, 0);
    renderMessage("Ready I2C\nSlave");

    Serial.printf("Slave addr=0x%02X\n", I2C_SLAVE_ADDR);
}

void loop() {
    static uint32_t lastDemoMs = 0;
    static uint32_t demoCounter = 0;

    if (msgReady) {
        noInterrupts();
        char localBuf[MSG_BUF_SIZE];
        uint8_t localLen = msgLen;
        memcpy(localBuf, msgBuf, localLen + 1);
        msgReady = false;
        interrupts();

        Serial.print("RX: ");
        Serial.println(localBuf);
        renderMessage(localBuf);
        lastDemoMs = millis();
    }

    if (!msgReady && (millis() - lastDemoMs >= 1000)) {
        char demoMsg[MSG_BUF_SIZE];
        snprintf(demoMsg, sizeof(demoMsg), "STM32 OK\nCount: %lu", (unsigned long)demoCounter++);
        renderMessage(demoMsg);
        lastDemoMs = millis();
    }

    delay(5);
}
