#ifndef CONFIG_H
#define CONFIG_H

#define I2C_SLAVE_SPEED_HZ      100000
#define LCD_I2C_SPEED_HZ        100000
#define SERIAL_BAUD             115200
#define MSG_BUF_SIZE            64

#endif // CONFIG_H
