#ifndef CONFIG_H
#define CONFIG_H

#define SERIAL_BAUD             115200
#define MSG_BUF_SIZE            64

#define I2C_SLAVE_ADDR          0x12
#define I2C_SLAVE_SDA_PIN       21
#define I2C_SLAVE_SCL_PIN       22
#define I2C_SLAVE_SPEED_HZ      100000

#define LCD_I2C_SDA_PIN         32
#define LCD_I2C_SCL_PIN         33
#define LCD_I2C_SPEED_HZ        100000
#define LCD_ADDR                0x27
#define LCD_COLS                16
#define LCD_ROWS                4

#endif // CONFIG_H
