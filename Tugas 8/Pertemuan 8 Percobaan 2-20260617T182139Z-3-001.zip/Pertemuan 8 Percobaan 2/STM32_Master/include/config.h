#ifndef CONFIG_H
#define CONFIG_H

#define SERIAL_BAUD             115200
#define SEND_INTERVAL_MS        1000

#define I2C_MASTER_SDA_PIN      PB7
#define I2C_MASTER_SCL_PIN      PB6
#define I2C_MASTER_SPEED_HZ     100000
#define I2C_SLAVE_ADDR          0x12

#endif // CONFIG_H
