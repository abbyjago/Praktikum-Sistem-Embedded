#include <Arduino.h>
#include <Wire.h>
#include "config.h"

static const char kMessage[] = "HAIKAL GANTENG";

void setup() {
    Serial.begin(SERIAL_BAUD);
    delay(1500);

    Serial.println("STM32 I2C master start");
#ifdef BUILD_DATE
    Serial.print("Build date: ");
    Serial.println(BUILD_DATE);
#endif

    Wire.setSDA(I2C_MASTER_SDA_PIN);
    Wire.setSCL(I2C_MASTER_SCL_PIN);
    Wire.begin();
    Wire.setClock(I2C_MASTER_SPEED_HZ);
}

void loop() {
    Wire.beginTransmission(I2C_SLAVE_ADDR);
    Wire.write(reinterpret_cast<const uint8_t *>(kMessage), sizeof(kMessage) - 1);
    uint8_t result = Wire.endTransmission();

    Serial.print("TX -> addr 0x");
    Serial.print(I2C_SLAVE_ADDR, HEX);
    Serial.print(" status=");
    Serial.println(result);

    delay(SEND_INTERVAL_MS);
}
