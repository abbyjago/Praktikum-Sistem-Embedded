#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

#define DHTPIN 16
#define DHTTYPE DHT22

const uint8_t kLcdAddress = 0x27;
const uint8_t kLcdCols = 16;
const uint8_t kLcdRows = 4;

LiquidCrystal_I2C lcd(kLcdAddress, kLcdCols, kLcdRows);
DHT dht(DHTPIN, DHTTYPE);

static void showBootMessage() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("ESP32 DHT22");
  lcd.setCursor(0, 1);
  lcd.print("LCD 16x4 I2C");
  lcd.setCursor(0, 2);
  lcd.print("Init...");
}

static void showSensorValues(float temperatureC, float humidity) {
  lcd.setCursor(0, 0);
  lcd.print("Suhu: ");
  if (isnan(temperatureC)) {
    lcd.print("--.- C   ");
  } else {
    lcd.print(temperatureC, 1);
    lcd.print(" C   ");
  }

  lcd.setCursor(0, 1);
  lcd.print("Hum : ");
  if (isnan(humidity)) {
    lcd.print("--.- %   ");
  } else {
    lcd.print(humidity, 1);
    lcd.print(" %   ");
  }

  if (!isnan(temperatureC) && !isnan(humidity)) {
    float heatIndex = dht.computeHeatIndex(temperatureC, humidity, false);
    lcd.setCursor(0, 2);
    lcd.print("Heat: ");
    lcd.print(heatIndex, 1);
    lcd.print(" C   ");
  } else {
    lcd.setCursor(0, 2);
    lcd.print("Heat: --.- C");
  }

  lcd.setCursor(0, 3);
  lcd.print("Update: 2s");
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);

  lcd.init();
  lcd.backlight();
  showBootMessage();

  dht.begin();
  delay(1500);
}

void loop() {
  float humidity = dht.readHumidity();
  float temperatureC = dht.readTemperature();

  if (isnan(humidity) || isnan(temperatureC)) {
    Serial.println("Failed to read from DHT22");
  } else {
    Serial.print("Temp: ");
    Serial.print(temperatureC);
    Serial.print(" C  Hum: ");
    Serial.print(humidity);
    Serial.println(" %");
  }

  showSensorValues(temperatureC, humidity);
  delay(2000);
}
