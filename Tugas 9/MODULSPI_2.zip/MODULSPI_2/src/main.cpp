﻿#include <Arduino.h>
#include <SPI.h>

#if defined(ESP32)

const int PIN_SS   = 5;
const int PIN_SCK  = 18;
const int PIN_MISO = 19;
const int PIN_MOSI = 23;

const char message[] = "Hello World";

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("ESP32 SPI Master - start");

  pinMode(PIN_SS, OUTPUT);
  digitalWrite(PIN_SS, HIGH);
  SPI.begin(PIN_SCK, PIN_MISO, PIN_MOSI, PIN_SS);
}

void loop() {
  size_t len = strlen(message);

  digitalWrite(PIN_SS, LOW);
  SPI.transfer(0xA5);            // start marker
  SPI.transfer((uint8_t)len);    // kirim panjang pesan

  for (size_t i = 0; i < len; i++) {
    SPI.transfer(message[i]);
  }

  // Terima balasan pesan asli dari slave
  uint8_t marker = SPI.transfer(0x00);
  if (marker == 0xA5) {
    uint8_t replyLen = SPI.transfer(0x00);
    Serial.printf("Reply length: %d\n", replyLen);
    char replyBuffer[64];
    for (uint8_t i = 0; i < replyLen; i++) {
      replyBuffer[i] = SPI.transfer(0x00);
    }
    replyBuffer[replyLen] = '\0';
    Serial.print("Master received reply: ");
    Serial.println(replyBuffer);
  }

  // Terima pesan status dari slave
  marker = SPI.transfer(0x00);
  if (marker == 0xB5) {  // marker status
    uint8_t statusLen = SPI.transfer(0x00);
    Serial.printf("Status length: %d\n", statusLen);
    char statusBuffer[64];
    for (uint8_t i = 0; i < statusLen; i++) {
      statusBuffer[i] = SPI.transfer(0x00);
    }
    statusBuffer[statusLen] = '\0';
    Serial.println(statusBuffer);  // tampilkan status slave
  }

  digitalWrite(PIN_SS, HIGH);

  Serial.print("Master sent message: ");
  Serial.println(message);
  delay(2000);
}

#elif defined(ARDUINO_ARCH_STM32F1) || defined(ARDUINO_ARCH_STM32)

const int PIN_SS = 4; // PA4 for SPI1 NSS on Nucleo F103RB
char buffer[64];
uint8_t expectedLen = 0;
uint8_t indexPos = 0;
bool receiving = false;

void setup() {
  // Serial.begin(115200);
  // delay(100);
  // Serial.println("STM32 SPI Slave - ready to receive");

  pinMode(PIN_SS, INPUT_PULLUP);
  SPI.begin();
}

void loop() {
  if (digitalRead(PIN_SS) == LOW) {
    uint8_t received = SPI.transfer(0x00);

    if (!receiving) {
      if (received == 0xA5) {
        receiving = true;
        expectedLen = 0;
        indexPos = 0;
      }
    } else if (expectedLen == 0) {
      expectedLen = min(received, (uint8_t)(sizeof(buffer) - 1));
    } else {
      if (indexPos < expectedLen) {
        buffer[indexPos++] = (char)received;
      }

      if (indexPos >= expectedLen) {
        buffer[indexPos] = '\0';
        // Serial.print("Slave received message: ");
        // Serial.println(buffer);  // hapus, kirim via SPI

        // Kirim balik pesan yang sama
        SPI.transfer(0xA5);  // marker balik
        SPI.transfer((uint8_t)strlen(buffer));  // panjang balik
        for (size_t i = 0; i < strlen(buffer); i++) {
          SPI.transfer(buffer[i]);
        }

        // Kirim pesan status ke master
        const char statusMsg[] = "Slave received message: Hello World";
        SPI.transfer(0xB5);  // marker status
        SPI.transfer((uint8_t)strlen(statusMsg));
        for (size_t i = 0; i < strlen(statusMsg); i++) {
          SPI.transfer(statusMsg[i]);
        }

        receiving = false;
        // Terus transfer dummy sampai master lepaskan SS
        while (digitalRead(PIN_SS) == LOW) {
          SPI.transfer(0x00);
        }
      }
    }

    while (digitalRead(PIN_SS) == LOW) {
      // tetap dalam loop sampai master release SS
    }
  }
}

#else
#error "This sketch supports only ESP32 and STM32 targets."
#endif
